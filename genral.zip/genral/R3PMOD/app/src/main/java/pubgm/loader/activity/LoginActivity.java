package pubgm.loader.activity;

import static pubgm.loader.livai.R3pmodking.LINKVIP;
import static pubgm.loader.livai.R3pmodking.getOwner;
import static pubgm.loader.livai.R3pmodking.getuser;
import static pubgm.loader.livai.R3pmodking.getchrome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

import androidx.annotation.Nullable;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import pubgm.loader.Component.Prefs;
import pubgm.loader.Component.DownloadZip;
import pubgm.loader.R;
import pubgm.loader.utils.ActivityCompat;

import android.content.ClipData;
import android.content.ClipboardManager;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;

import java.util.Locale;

import org.json.JSONObject;

public class LoginActivity extends ActivityCompat {

    static {
        System.loadLibrary("livai");
    }

    public static int REQUEST_OVERLAY_PERMISSION = 5469;
    private static final String USER = "USER";
    public static String USERKEY, PASSKEY;
    private Prefs prefs;
    private AlertDialog loadingDialog;
    private static int loginCounter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setAppLocale();
        setLightStatusBar(this);
        setContentView(R.layout.activity_login);
        initDesign();
        OverlayPermission();

        TextInputLayout passwordLayout = findViewById(R.id.password_layout);
        TextInputEditText textUsername = findViewById(R.id.textUsername);
        textUsername.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        textUsername.setGravity(android.view.Gravity.CENTER);

        passwordLayout.setEndIconOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard.hasPrimaryClip()) {
                ClipData clipData = clipboard.getPrimaryClip();
                if (clipData != null && clipData.getItemCount() > 0) {
                    CharSequence pastedText = clipData.getItemAt(0).getText();
                    if (pastedText != null) {
                        textUsername.setText(pastedText.toString());
                    }
                }
            }
        });

        ImageView iconTelegram = findViewById(R.id.iconTelegram);
        ImageView iconUser = findViewById(R.id.iconUser);
        ImageView iconChrome = findViewById(R.id.iconChrome);

        iconTelegram.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(getOwner()));
            startActivity(intent);
        });

        iconUser.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(getuser()));
            startActivity(intent);
        });

        iconChrome.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(getchrome()));
            startActivity(intent);
        });

        new Handler().postDelayed(this::startAnimations, 300);
    }

    private void setAppLocale() {
        String lang = Locale.getDefault().getLanguage();
        String finalLang = "en";

        if (lang.startsWith("ar")) {
            finalLang = "ar";
        } else if (lang.startsWith("zh")) {
            finalLang = "zh";
        } else if (lang.startsWith("ku")) {
            finalLang = "ku";
        } else if (lang.startsWith("en")) {
            finalLang = "en";
        }

        Locale locale = new Locale(finalLang);
        Locale.setDefault(locale);
        Resources res = getResources();
        Configuration config = res.getConfiguration();
        config.setLocale(locale);
        res.updateConfiguration(config, res.getDisplayMetrics());
    }

    private void startAnimations() {
        View logoImage = findViewById(R.id.logoImage);
        View appTitle = findViewById(R.id.appTitle);
        View passwordLayout = findViewById(R.id.password_layout);

        AnimatorSet logoAnimator = new AnimatorSet();
        logoAnimator.playTogether(
                ObjectAnimator.ofFloat(logoImage, "translationY", 0),
                ObjectAnimator.ofFloat(logoImage, "alpha", 1),
                ObjectAnimator.ofFloat(logoImage, "rotation", 0, -720)
        );
        logoAnimator.setDuration(1000);
        logoAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        logoAnimator.start();

        logoAnimator.addListener(new android.animation.Animator.AnimatorListener() {
            @Override public void onAnimationStart(android.animation.Animator animation) {}
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                new Handler().postDelayed(() -> {
                    AnimatorSet titleAnimator = new AnimatorSet();
                    titleAnimator.playTogether(
                            ObjectAnimator.ofFloat(appTitle, "translationY", 0),
                            ObjectAnimator.ofFloat(appTitle, "alpha", 1)
                    );
                    titleAnimator.setDuration(600);
                    titleAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
                    titleAnimator.start();

                    titleAnimator.addListener(new android.animation.Animator.AnimatorListener() {
                        @Override public void onAnimationStart(android.animation.Animator animation) {}
                        @Override public void onAnimationEnd(android.animation.Animator animation) {
                            new Handler().postDelayed(() -> {
                                AnimatorSet passwordAnimator = new AnimatorSet();
                                passwordAnimator.playTogether(
                                        ObjectAnimator.ofFloat(passwordLayout, "translationY", 0),
                                        ObjectAnimator.ofFloat(passwordLayout, "alpha", 1)
                                );
                                passwordAnimator.setDuration(500);
                                passwordAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
                                passwordAnimator.start();

                                passwordAnimator.addListener(new android.animation.Animator.AnimatorListener() {
                                    @Override public void onAnimationStart(android.animation.Animator animation) {}
                                    @Override public void onAnimationEnd(android.animation.Animator animation) {
                                        new Handler().postDelayed(() -> animateLoginButton(), 300);
                                    }
                                    @Override public void onAnimationCancel(android.animation.Animator animation) {}
                                    @Override public void onAnimationRepeat(android.animation.Animator animation) {}
                                });
                            }, 400);
                        }
                        @Override public void onAnimationCancel(android.animation.Animator animation) {}
                        @Override public void onAnimationRepeat(android.animation.Animator animation) {}
                    });
                }, 500);
            }
            @Override public void onAnimationCancel(android.animation.Animator animation) {}
            @Override public void onAnimationRepeat(android.animation.Animator animation) {}
        });
    }

    private void animateLoginButton() {
        View loginBtn = findViewById(R.id.loginBtn);

        AnimatorSet buttonAnimator = new AnimatorSet();
        buttonAnimator.playTogether(
                ObjectAnimator.ofFloat(loginBtn, "translationY", 0),
                ObjectAnimator.ofFloat(loginBtn, "alpha", 1),
                ObjectAnimator.ofFloat(loginBtn, "scaleX", 1f),
                ObjectAnimator.ofFloat(loginBtn, "scaleY", 1f)
        );
        buttonAnimator.setDuration(600);
        buttonAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        buttonAnimator.start();

        buttonAnimator.addListener(new android.animation.Animator.AnimatorListener() {
            @Override public void onAnimationStart(android.animation.Animator animation) {}
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                new Handler().postDelayed(this::animateIconsWithBounce, 200);
            }
            private void animateIconsWithBounce() {
                View iconsLayout = findViewById(R.id.iconsLayout);
                AnimatorSet layoutAnimator = new AnimatorSet();
                layoutAnimator.playTogether(
                        ObjectAnimator.ofFloat(iconsLayout, "translationY", 0),
                        ObjectAnimator.ofFloat(iconsLayout, "alpha", 1)
                );
                layoutAnimator.setDuration(600);
                layoutAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
                layoutAnimator.start();
            }
            @Override public void onAnimationCancel(android.animation.Animator animation) {}
            @Override public void onAnimationRepeat(android.animation.Animator animation) {}
        });
    }

    public void initDesign() {
        prefs = Prefs.with(this);
        final Context m_Context = this;
        TextView textUsername = findViewById(R.id.textUsername);
        MaterialButton btnSignIn = findViewById(R.id.loginBtn);
        textUsername.setText(prefs.read(USER, ""));
        btnSignIn.setOnClickListener(v -> {
            TextView errorUsername = findViewById(R.id.error_username);
            if (!textUsername.getText().toString().isEmpty()) {
                prefs.write(USER, textUsername.getText().toString());
                String userKey = textUsername.getText().toString().trim();
                loadingDialog = showLoadingDialog();
                loginCounter++;
                if (loginCounter % 5 == 0) {
                    loadingDialog.dismiss();
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(getOwner()));
                    startActivity(intent);
                    finish();
                    return;
                }
                String jsonUrl = LINKVIP();
                Login(LoginActivity.this, userKey, loadingDialog, jsonUrl);
                USERKEY = userKey;
                PASSKEY = userKey;
                errorUsername.setVisibility(View.GONE);
            } else {
                errorUsername.setText(getString(R.string.please_enter_username));
                errorUsername.setVisibility(View.VISIBLE);
            }
        });
    }

    private void setLightStatusBar(Activity activity) {
        activity.getWindow().setStatusBarColor(Color.parseColor("#FFFFFF"));
        activity.getWindow().setNavigationBarColor(Color.parseColor("#FFFFFF"));
    }

    public void OverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
                builder.setMessage(R.string.please_allow_permision_floating);
                builder.setPositiveButton(R.string.yes, (p1, p2) -> {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
                });
                builder.setCancelable(false);
                builder.show();
            }
        }
    }

    private void Login(final Context m_Context, final String userKey, final AlertDialog loadingDialog, final String jsonUrl) {
        final Handler loginHandler = new Handler(msg -> {
            if (msg.what == 0) {
                new DownloadZip.CheckJson(m_Context, new DownloadZip.OnDownloadCompleteListener() {
                    private AlertDialog downloadDialog;
                    @Override
                    public void onPreExecute() {
                        if (loadingDialog != null && loadingDialog.isShowing()) {
                            loadingDialog.dismiss();
                        }
                        downloadDialog = showLoadingDialog();
                    }
                    @Override
                    public void onDownloadComplete(boolean success) {
                        if (downloadDialog != null && downloadDialog.isShowing()) {
                            downloadDialog.dismiss();
                        }
                        if (success) {
                            Intent i = new Intent(m_Context.getApplicationContext(), MainActivity.class);
                            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            i.putExtra("USER_KEY", userKey);
                            m_Context.startActivity(i);
                            finish();
                        }
                    }
                }).execute(jsonUrl);
            } else if (msg.what == 1) {
                loadingDialog.dismiss();
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(getOwner()));
                startActivity(intent);
                finish();
            }
            return true;
        });
        new Thread(() -> {
            String result = suckmydick(m_Context, userKey);
            if (result.equals("OK")) {
                loginHandler.sendEmptyMessage(0);
            } else {
                Message msg = new Message();
                msg.what = 1;
                msg.obj = result;
                loginHandler.sendMessage(msg);
            }
        }).start();
    }

    private AlertDialog showLoadingDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.animation_login, null);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(false);
        dialog.show();
        return dialog;
    }

    private static native String suckmydick(Context mContext, String userKey);
}