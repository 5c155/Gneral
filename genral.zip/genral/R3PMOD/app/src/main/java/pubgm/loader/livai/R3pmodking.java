package pubgm.loader.livai;

public class R3pmodking {

    static {
       
            System.loadLibrary("livai");
        } 

    public static native String mainURL();
    public static native String getOwner();
    public static native String getchrome();
    public static native String getuser();
    public static native String activity();
    public static native String sockindia();
    public static native String sockallversion();
    public static native String CheckServer();
    public static native String EXP();
    public static native String Pw();
    public static native String LINKVIP();
    public static native String ApiKeyBox();

}
